package com.zhaixin.globalexception;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GlobalexceptionApplication {

    public static void main(String[] args) {
        SpringApplication.run(GlobalexceptionApplication.class, args);
    }

}
